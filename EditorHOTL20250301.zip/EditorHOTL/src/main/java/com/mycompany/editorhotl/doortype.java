/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.editorhotl;

/**
 *
 * @author levi
 */
    public class doortype{//Changed to int, since this is not anything special anyways, and not much memory.
	int up;
	int down;
	int falldown;
	int unused1;
	int waterfall;
	int unused2;
	int unused3;
	int compassShow;
}
