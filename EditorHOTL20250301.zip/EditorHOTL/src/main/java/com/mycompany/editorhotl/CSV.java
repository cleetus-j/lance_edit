package com.mycompany.editorhotl;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;



public class CSV {


    public static byte[] getCSV(String filePath) throws IOException {
        return Files.readAllBytes(Paths.get(filePath));
    }   //Generic CSV import.
    public static byte[] importCSVnames(String filePath) throws IOException {
    byte[] result= Files.readAllBytes(Paths.get(filePath));
    if (result.length!=(0x80)) {
        System.out.println("The filesize is not right: "+result.length);
        System.exit(-1);
    }
    return result;
    }   //Only for char name import.
    public static boolean checkNames(ArrayList<String> input){
       /*This checks the name validity with a name CSV.
       You need to have eight lines, and each name must not exceed 14 characters.
       * */
       String work; //This might be not needed.
       boolean check=false;

       if (input.size()!=8){    //Check the lines in the imported file.
           System.out.println("Invalid CSV Length: "+input.size()); //Uh-oh, the line nr. don't match.
           return check;
       }else{//Line nr is good, let's check the individial names.
        for (int i = 0; i < input.size(); i++) {
            work=input.get(i);  //Get a line in the temp var.
            if(work.length()>14){
                check=false;
                System.out.println("Error on line "+i+" , name is longer than 14 chars.");
                return check;   //Ayy, the name length is not right, we shall return with false.
            }else{
                check=true;
            }
        }}

       return check;
    }   //This checks a CSV that has names in it for the character. Rewritten for arraylists. I think this does not needed at all, there are much better alternatives in this code already.
    public static void exportCSV(byte[]input, String path) throws FileNotFoundException {
try {
        FileOutputStream fileOutputStream=new FileOutputStream(path);
        fileOutputStream.write(input);
        fileOutputStream.close();
        System.out.println("The file was written successfully.");
} catch (RuntimeException | IOException e) {
    throw new RuntimeException(e);
}

    }       //What the name suggests.
}
