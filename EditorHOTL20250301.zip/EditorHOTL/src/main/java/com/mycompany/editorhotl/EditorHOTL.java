/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.editorhotl;


import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.swing.*;
import java.awt.*;

//import org.apache.commons.lang3.ArrayUtils;
/**
 *
 * @author levi
 */
public class EditorHOTL {


//public class Main {
    public static void main(String[] args) throws IOException {

        byte[] chars =new byte[263]; //This is the amount of the whole array in the ROM. This is for all eight characters.
        rom original=new rom(); //Create a ROM object, so we can access its parameters.
        String fileName= original.path+original.fileName;   //The filename here needs to be adjusted, this was done on the laptop.
        byte[] rom= com.mycompany.editorhotl.rom.readRom(fileName);   //Desktop location.(VOS)
        enemy.printNme(rom);
        String input="/media/MegaWork/devver/disas/HOTL/anotherexam/editor/room_vram/HOTL_mod_ah1.vrm";
        String inputRAM="/media/MegaWork/devver/disas/HOTL/anotherexam/editor/room_ram/HOTL_mod_ah1.ramtrunc";

        byte[]testArray=new byte[4096];
        byte[]testArray2=new byte[4096];
        VRAM stuff=new VRAM();
        levelRAMArray levelRAMArray=new levelRAMArray();
        testArray=stuff.readFile(input);
        testArray2=stuff.readFile(inputRAM);
        BufferedImage testing=stuff.decodeTiles(testArray,8,64,512,stuff.colorPalette);
        BufferedImage[] testImgArray= com.mycompany.editorhotl.levelRAMArray.splitImageInto8x8Tiles(testing,false); //This makes tiles from a VRAM image dump.
        BufferedImage metaTileTest= com.mycompany.editorhotl.levelRAMArray.combineTiles(testImgArray,testArray2,true);
    /*        JFrame jFrame=new JFrame();
            jFrame.setSize(800,600);
            jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            jFrame.setTitle("HOTL Editor");
    ImageIcon imageIcon=new ImageIcon(testing);
    JLabel jLabel=new JLabel();
    jLabel.setIcon(imageIcon);
    jFrame.add(jLabel);
    Dimension size=jLabel.getPreferredSize();   //TODO: Place the VRAM image on the right side, or if it's better, then place it on the left side, just elsewhere.
            jFrame.setVisible(true); */
}

}

