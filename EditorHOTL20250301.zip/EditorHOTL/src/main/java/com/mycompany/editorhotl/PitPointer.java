/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.editorhotl;

/**
 *
 * @author levi
 */
public class PitPointer {
    int pitLocation;    //This is the absolute address of the pit in the ROM.
    int pitCount;      //How many pits are on the given room. This can and will be used for the pit coordinates.
    PitCoordinate[] pits=new PitCoordinate[pitCount];   //Depending on how many pits are, we might need an array for this.
    
}
