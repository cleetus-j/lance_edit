package com.mycompany.editorhotl;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class levelRAMArray {
    byte[] level=new byte[4096];
    VRAM VRAMDump=new VRAM();
    String room_ram="/media/MegaWork/devver/disas/HOTL/anotherexam/editor/room_ram/";
    String VRAMDumpPath="/media/MegaWork/devver/disas/HOTL/anotherexam/editor/room_vram/";
    String FileNamePart1="HOTL_mod_ah"; //This is how filenames are saved. Change it if you want something else.
    String[] extensions={".vrm",".ram"};    //Combine the extensions.
    BufferedImage levelPic=new BufferedImage(4096,144, BufferedImage.TYPE_INT_RGB); //This is the maximum level size that can be defined with the engine.
    BufferedImage[] metaTiles=new BufferedImage[256];   //FF is probably too much, since at no point uses the game this much of data, there's no VRAM for it.
    BufferedImage[] tiles=new BufferedImage[512];   //This is for the normal tiles. 512 can be used.

    /*
    * This is just the levels as how they are represented in the system memory, uncompressed.
    * I think I explained the level structure in the disassembly, but here's the gist of it.
    * The level is made from 16x16 blocks, eight slices. The levels are stored like rows\stripes if you will.
    * This means the maximum level length with this game engine is 256*16 blocks.
    * Every 16x16 metatile is made up from smaller tiles of course.
    * The first 256 bytes are the first tiles of said metatiles.
    * Then the second 256 bytes are offsets, if the game uses the first or the second set of tiles.
    * Then comes the second tile and the rest. This is 1k of data. Of course, there's a lot of free space in this, since the
    * game could not use that many tiles for BG graphics, and it's usually not that "artsy" anyway.
    * After this, the rest are the bigger metatiles, row by row.
    * The code that loads the level also gets which bank to load the graphics from, but that's not really something I wanted to jump into.
    *
    * The graphics in VRAM are loaded sequentially, after the HUD graphics. Four tiles are one metatile one after another starting at $2180.
    * At least the game loads there.
    * Based on what does the game load tiles, I don't know yet. The code that handles level loading is not easy to follow after a while. I may lack the
    * necessary skill to do it.
    *
    *
    * What I want to do is, to make up a tilemap from the mapdata. And with that, I could rebuild and show it as a VRAM dump converted to images to see the full levels.
    * This way, at least we can see what's used, and what's not. More than that, it would give an easier interface to build levels. Maybe to have a nice GUI, a HEX editor, and
    * some frequent refresh.
    *
    * The second 255 bytes handle extra data, such as tile flipping.
    *   -Byte 0:    0:Tile fetched from the first 256 tiles.    1:Tile fetched from the second 256 tiles.
    *   -Byte 1:    0:Tile is not flipped horizontally.   1:Tile is flipped.
    *   -Byte 2:    0:Tile is not flipped vertically. 1:Tile is flipped.
    *   -Byte 3:    This does not do anything, but I suspect that it controls which palette is used for the given tile.
    *                   Since the first and second palette uses 4-5 shared colors, this bit does nothing in this context.
    *   -Byte 4:    This controls the tile priority. 0 is behind sprites, 1 is in front of.
    * Other bits do nothing. Byte 0 is always 1, since all tile data for the background is coming from the second part of VRAM.
    * The game does not use tile priority, so that's one byte less to care about.
    * Flipping IS used, though not very extensively. So for the background, you need two bytes to handle everything.
    * */
    //These are the strips of 16x16 or 2x2 metatiles. This is how you "draw" a level.
    /*
    * The level drawing should be done this way maybe:
    *   Once we converted every level VRAM dump, with right colors and everything, then start to make an array from the metatiles, represented as normal tiledata.
    * First, the tiles fetched, then transformed according to the second bytes.
    * Once that's done, then we'll process the level line by line:
    *
    * */
    public byte[] ImportLevelArrayNumbers(int lvlNr){
    byte[] result=new byte[8192];   //SMS Ram is 8k.
        rom file=new rom();
        String path1=this.room_ram+this.FileNamePart1+lvlNr+this.extensions[1];   //RAM dump.
        //String path2=this.VRAMDumpPath+this.FileNamePart1+lvlNr+this.extensions[0];   //VRAM dump.
        result=file.readRom(path1); //This is the result of the read, and we can query it.
        return result;
    }   //This opens the level array, but you just have to give a valid room nr.
public byte[] ImportLevelArray(String inputPath){
    rom file=new rom();
    byte[] result=file.readRom(inputPath);  //We need the RAM dump that we'll open to handle shit.
    String[] fname=inputPath.split("/");    //Extract the filename from the path we just gave.

    String fname2=fname[fname.length];  //We need the last element of the String array.
    fname2=replaceLastThree(fname2,"ram");  //Replace the extension of the filename.
    String levelArrayPath=this.room_ram+fname2; //Combine the path and the name with the new extension.
    /*Pattern pattern = Pattern.compile("\\d+");

    // Create a matcher for the input string
    Matcher matcher = pattern.matcher(fname2);

    // Find all matches and concatenate them
    StringBuilder numbers = new StringBuilder();
    while (matcher.find()) {
        numbers.append(matcher.group());
    }
    //numbers contains now the number we need to use to get the matching VRAM dump. This is of course a TODO.
    //On second thought, I named files the same, just the folder and extension is different.
    */  //This is not needed at the moment, previously I thought the files are named differently.
    return result;
}       //Normal file opener.
    public static String replaceLastThree(String original, String replacement) {
        // Check if the original string has at least 3 characters
        if (original.length() < 3) {
            throw new IllegalArgumentException("Original string must have at least 3 characters.");
        }

        // Get the substring excluding the last 3 characters
        String substring = original.substring(0, original.length() - 3);

        // Concatenate the substring with the replacement
        return substring + replacement;
    }       //Not really used, but does what is says on the can.
    public static BufferedImage[] splitImageInto8x8Tiles(BufferedImage image, boolean exportTiles) {
        int tileWidth = 8;
        int tileHeight = 8;

        // Calculate the number of tiles in rows and columns
        int cols = image.getWidth() / tileWidth;
        int rows = image.getHeight() / tileHeight;

        // Create an array to hold the tiles
        BufferedImage[] tiles = new BufferedImage[cols * rows];

        // Iterate over the image in 8x8 blocks (row by row, then column by column)
        int tileIndex = 0;
        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < cols; x++) {
                // Create a new BufferedImage for the tile
                BufferedImage tile = new BufferedImage(tileWidth, tileHeight, image.getType());

                // Copy the pixel data from the original image to the tile
                for (int ty = 0; ty < tileHeight; ty++) {
                    for (int tx = 0; tx < tileWidth; tx++) {
                        int pixel = image.getRGB(x * tileWidth + tx, y * tileHeight + ty);
                        tile.setRGB(tx, ty, pixel);
                    }
                }

                // Add the tile to the array
                tiles[tileIndex] = tile;

                // Export the tile as a PNG file if exportTiles is true
                if (exportTiles) {
                    try {
                        String outputPath = String.format("/media/MegaWork/devver/disas/HOTL/anotherexam/editor/tileImg/tile_%d_%d.png", y, x); // File name based on tile position (row, column)
                        ImageIO.write(tile, "png", new File(outputPath));
                        System.out.println("Exported: " + outputPath);
                    } catch (IOException e) {
                        System.err.println("Failed to export tile: " + e.getMessage());
                    }
                }

                tileIndex++;
            }
        }

        return tiles;
    }   //This returns with the small tiles from a VRAM image for example.
    public void handleTileAttr(){   //TODO: this could be used for the attributes.



    }
    /**
     * Combines 8x8 tiles into a 16x16 image based on a byte array.
     *
     * @param tileArray     Array of 8x8 BufferedImages (tiles).
     * @param sourceData    Byte array where each byte is an index into the tileArray.
     * @param exportImage   If true, exports the combined image as a PNG file.
     * @return The combined 16x16 BufferedImage.
     */
    public static BufferedImage combineTiles(BufferedImage[] tileArray, byte[] sourceData, boolean exportImage) {
        // Create a 16x16 BufferedImage to hold the combined result
        BufferedImage largerImage = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);

        // Define the positions of the tiles in the larger image
        int[][] tilePositions = {
                {0, 0},   // Tile 1: Upper-left
                {8, 0},   // Tile 2: Upper-right
                {8, 8},   // Tile 3: Lower-right
                {0, 8}    // Tile 4: Lower-left
        };

        // Iterate over the four tiles
        for (int tileIndex = 0; tileIndex < 4; tileIndex++) {
            // Get the tile index from the source data (512 bytes apart)
            int sourceOffset = tileIndex * 512;
            //sourceOffset+=256;

            byte tileIndexByte = sourceData[sourceOffset];

            // Convert the byte to an integer index (unsigned byte)
            int tileArrayIndex = tileIndexByte & 0xFF;
            tileArrayIndex+=256;    //This should be handled along with the attributes, though the game never uses the first 256 tiles for level stuff.
            System.out.println(String.format("0x%02X", tileArrayIndex));
            // Get the corresponding 8x8 tile from the tileArray
            BufferedImage tile = tileArray[tileArrayIndex];

            // Get the position of the tile in the larger image
            int destX = tilePositions[tileIndex][0];
            int destY = tilePositions[tileIndex][1];

            // Copy the tile into the larger image
            for (int y = 0; y < 8; y++) {
                for (int x = 0; x < 8; x++) {
                    int pixel = tile.getRGB(x, y); // Get the pixel from the tile
                    largerImage.setRGB(destX + x, destY + y, pixel); // Set the pixel in the larger image
                }
            }
        }

        // Export the larger image as a PNG file if exportImage is true
        if (exportImage) {
            try {
                File outputFile = new File("/media/MegaWork/devver/disas/HOTL/anotherexam/editor/tileImg/combined_image.png");
                ImageIO.write(largerImage, "png", outputFile);
                System.out.println("Exported combined image to: " + outputFile.getAbsolutePath());
            } catch (IOException e) {
                System.err.println("Failed to export image: " + e.getMessage());
            }
        }

        return largerImage;
    }   //This builds bigger metatiles from smaller ones. You have to handle the tile flipping though.
}
