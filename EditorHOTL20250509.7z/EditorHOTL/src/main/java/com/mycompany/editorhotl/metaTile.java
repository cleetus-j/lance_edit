package com.mycompany.editorhotl;

public class metaTile {

    public byte[]tAndAttr=new byte[5*32];// 4 attribute bytes, and 4 32 byte tiles.
    /*The first 4 bytes are just for the tile attributes.
    Then comes 28 empty bytes. Deal with it. I might store some other stuff with it later on, who knows.
    Then comes the four tiles for the given metatile
    */
}
