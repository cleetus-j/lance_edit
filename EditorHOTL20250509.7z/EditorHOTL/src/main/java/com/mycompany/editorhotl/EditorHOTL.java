package com.mycompany.editorhotl;

public class EditorHOTL {
    public static void main(){
    rom workRom=new rom();
    }
}