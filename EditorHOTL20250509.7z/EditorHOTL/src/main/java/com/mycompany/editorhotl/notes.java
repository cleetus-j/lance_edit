package com.mycompany.editorhotl;

public class notes {
  /*
  * This is a dummy file of course, to take notes is.
  * TODO:
  *   The Hex editor is okay, has everything it needs as for now. It is connected to the main
  * application window, and does not exit badly, as it did before.
  * I would need to open a level in the HEx editor, that opens the relevant VRAM file.
  * It should automatically draw the image of the level.
  *
  * When you edit the file with the hex editor, it should redraw the level automatically.
  * Editing graphics are not inside the editor's job.
  * It extracts metatiles and tiles too.
  * Showing metatiles might be good on another window.
  *
  * A small editor, that has a grid and the program will show an arbitrary sized metatile
  * arrangement, this is especially good for doors, and other bigger structures. Maybe entering
  * manual data to the levels is not that bad for now.
  *
  * there should be a button for the metatile import, and individual tiles. there should be a
  * button to reload the same source file, therefore making work faster. the import CSV should
  * have more columns, to be able to see easier the various mirrorings and things like that.
  * */
}
