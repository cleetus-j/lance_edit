/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.editorhotl;

/**
 *
 * @author levi
 */
public class PitCoordinate {
    int[] PitCoordinate=new int[2]; //The starting and the ending columns.
    int PitEnd=0;
    
}
