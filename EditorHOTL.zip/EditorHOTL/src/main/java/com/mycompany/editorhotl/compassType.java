/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.editorhotl;

/**
 *
 * @author levi
 * Work in progress. This is for the levelDetails class, to hold what type of compass a level uses, like how it looks on the screen. See the HUD of the game.
 */
public class compassType {
    
}
