/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.editorhotl;


import java.io.IOException;
import javax.swing.*;
import java.awt.*;

//import org.apache.commons.lang3.ArrayUtils;
/**
 *
 * @author levi
 */
public class EditorHOTL {


//public class Main {
    public static void main(String[] args) {

        byte[] chars =new byte[263]; //This is the amount of the whole array in the ROM. This is for all eight characters.
        rom original=new rom(); //Create a ROM object, so we can access its parameters.
        String fileName= original.path+original.fileName;   //The filename here needs to be adjusted, this was done on the laptop.
        byte[] rom= com.mycompany.editorhotl.rom.readRom(fileName);   //Desktop location.(VOS)
        companion testing=new companion();
        testing.printchrinv(0);
}

}

