/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.editorhotl;

/**
 *
 * @author levi
 * This is a level descriptor. It has quite a few stuff that is needed to make up levels, such as where to get tiles, metatiles and floor data.
 * Some things i'm not sure what it does, but so far it's not needed. Later on, I want to use my own code to load levels, so most of these will not be used either.
 */
public class levelDetail {  //These are copied straight from the other code to define a level. Most of these are self explanatory.
    int roomNr;
    int _RAM_DE3E_MAX_LVL_LENGHT;
    int _RAM_DE31_METATILE_BANK;
    int _RAM_DE29_METATILE_TILE_LOAD;
    int _RAM_DE32_;
    int _RAM_DE2F_;
    int _RAM_DE2E_BANKSWITCH_LEVEL;
    int _RAM_DE2A_;
    int _RAM_DE5E_FLOORFALLXCOORD;
    int _RAM_DE60_;
    int _RAM_DE53_COMPASS;
}
