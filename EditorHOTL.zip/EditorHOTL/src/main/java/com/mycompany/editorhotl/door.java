/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.editorhotl;

/**
 *
 * @author levi
 */
    public class door{//This will hold the door object that we are extracting from the ROM.
/*
	This defines an individual door in the ROM, where the player can go through.
*/
	int doorAddress;		//This is the same as the door type address as well. This is valid in hexa.
   doortype door=new doortype();	//Individual bits are needed to be handled this way.
    byte roomnumber=0;
    byte columnplyrStarts=0;
    byte doorStart=0;
    byte doorEnd=0;
/*
At this point, I suspect there is some pattern with these things, but I have to map them still.
	I was right. The compass byte consists the following bits:
	0: If this is 1, then it's an upward exit.
	1: If this is 1, then this is a downward exit.
	2: If this is 1, then it's handled as the falldown stage exit from level 1.
	3: A bit unsure, it does not seem to do anything on it's own, or with the above bytes.
	4: Waterfall bit. If this is 1, then the game will tell the player the wfall will cure wounds, then proceeds to the destination.
	5: No effect.
	6: No effect.
	7: The compass will not mark the door!
	Bits 7+4 will enable waterfall effect.
    Bits 7+6 no mark, but works normally.
    Same for 7+5
    Same for 7+6+5
    Same for 7+4
    Unused bits seems to do nothing combined together, but if this is not the case, i'll update this.
    So, the compass data is another object for the future.
 * 
 */

    /*
     * 2acc-190d is 11BF which is 4543 bytes. I'm sure this is not all the doors in the game, so there might be some other data in this bunch.
     * There are 88 room entries, so anything over that is invalid probably. The byte definitions are also in the applied hacks disassembly, but i'll
     * put those details here as well:
     * First byte is the compass type. You either can go up or down. $01 is up, $02 is down. There is a compass variable elsewhere that will tell how it should be drawn.
     * Second byte is the room nr where the player will go if (s)he takes the door.
     * Third byte is the column number where the player will end up after taking the door.
     * Fourth byte tells the game which column the door begins.
     * Fifth bye is the end.
     * The door end and beginning is that when the game recognizes some place of the room as a door, it will not draw the door itself.
     * 
     */

    public static void printDoorDetails(byte[]rom) {//In the original ROM, there is an array at 0x190D that holds the door values to other rooms.
        //I don't know how many doors are in the array, so i'll print a few.
    /*
     * 2acc-190d is 11BF which is 4543 bytes. I'm sure this is not all the doors in the game, so there might be some other data in this bunch.
     * There are 88 room entries, so anything over that is invalid probably. The byte definitions are also in the applied hacks disassembly, but i'll
     * put those details here as well:
     * First byte is the compass type. You either can go up or down. $01 is up, $02 is down. There is a compass variable elsewhere that will tell how it should be drawn.
        There is a separate compass class, which tells more on how this is handled.
     * Second byte is the room nr where the player will go if (s)he takes the door.
     * Third byte is the column number where the player will end up after taking the door.
     * Fourth byte tells the game which column the door begins.
     * Fifth bye is the end.
     * The door end and beginning is that when the game recognizes some place of the room as a door, it will not draw the door itself.
     *
     */
        var doorOffset = 0x190D;
        var doorOffsetEnd = 0x2acc;
        int compassType, roomNr, columnNr, doorStart, doorEnd, doorNr, nrofDoors;
        String cString = "Compass type: ";
        String[] cType = {"Error", "North\\Up", "South\\Down", "3", "4", "5", "6"};
        String roomString = "Room destination: ";
        String columnNrString = "Destination column in target room: ";
        String startColumnString = "Door starting column: ";
        String endColumnString = "Door ending column: ";
        nrofDoors = 0;
        for (int i = doorOffset; i < (doorOffset + 700); i += 5) {  //Adjust one byte, since the second byte is the dest. room nr. As stated before, anything over 89 is invalid, maybe 90.
//for (int i = doorOffset; i < (doorOffset+500); i+=5) {  //Adjust one byte, since the second byte is the dest. room nr. As stated before, anything over 89 is invalid, maybe 90.
            // if (rom[i+1]<=89 & rom[i]>2) {  //TODO: Please check the validitiy of this, since if this is true, most of the rooms are not used, or points to room 0, which is invalid I think.
            nrofDoors++;
            //    System.out.println("--------------------------------------");
            //System.out.println(i);
            //System.out.println("Number of total valid doors: "+nrofDoors);//Room nr within 1-88-89 maybe.
            //    System.out.println("ROM Offset: "+String.format("0x%02X",i));   //Where in the ROM is this door exactly.
            //   System.out.println(String.format("0x%02X",rom[i])+" Compass Nr. in binary :"+Integer.toBinaryString(rom[i]));//There's a separate compass type which needs to be added to this.
            //    System.out.println((String.format("0x%02X",rom[i+1]))+" Dest.RoomNr in Decimals: "+rom[i+1]);//This will print the number of the destination room where the player will end up.
            //    System.out.println("Destination column for player spawn: "+(rom[i+2]&0xFF));    //Where will the player land in the destination room.
            //    System.out.println("Door Start column: "+(rom[i+3]&0xFF));
            //    System.out.println("Door End column: "+(rom[i+4]&0xFF));
            // } else {
            System.out.println("--------------------------------------");
            System.out.println("The number of doors are: " + (nrofDoors));
            System.out.println("ROM Offset: " + String.format("0x%02X", i));   //Where in the ROM is this door exactly.
            System.out.println(String.format("0x%02X", rom[i]) + " Compass Nr. in binary :" + Integer.toBinaryString(rom[i]));//There's a separate compass type which needs to be added to this.
            System.out.println((String.format("0x%02X", rom[i + 1])) + " Dest.RoomNr in Decimals: " + rom[i + 1]);//This will print the number of the destination room where the player will end up.
            System.out.println("Destination column for player spawn: " + (rom[i + 2] & 0xFF));    //Where will the player land in the destination room.
            System.out.println("Door Start column: " + (rom[i + 3] & 0xFF));
            System.out.println("Door End column: " + (rom[i + 4] & 0xFF));

            System.out.println("--------------------------------------");

        /*
        Level 1 has 25 doors.
        Level 2 has 36 doors, but i may have counted it wrong.
        Level 3 has 61 doors, but again, difficult to count on the map.
        The door array is very large, so I have no idea yet, if it has some unused door data in it. I have to list the doors based on rooms. I think the door data is already connected
        so this just plots whatever data is in there.
        */
            //}
    /*$00-no directions.
    $01-up only
    $02-down only
    $03-both
    $1a-down only
    $4a-down only
    $31 up only
    $06 down-ab
    $12 down
    $23 both
    $37 both
    $52 down
    $56 down
    $11 up
    $30 nothing
    $2E down
    $53 both
    $57 both
    $05 up
    $1D up
    $35 north
    $1C-nothing
    $19-south+waterfall
    $33 both+waterfall
    $51 up+waterfall
    $42 south
    $35 -up,waterfall,levelfall
    $45- up,alarm bells
    $13 both,wf
    $16 down,ab,wf
    $05-up,ab
    $1B-both,wf
    $78 nothing
    $2D up, ab
	At this point, I suspect there is some pattern with these things, but I have to map them still.
		I was right. The compass byte consists the following bits:
		0: If this is 1, then it's an upward exit.
		1: If this is 1, then this is a downward exit.
		2: If this is 1, then it's handled as the falldown stage exit from level 1.
		3: A bit unsure, it does not seem to do anything on it's own, or with the above bytes.
		4: Waterfall bit. If this is 1, then the game will tell the player the wfall will cure wounds, then proceeds to the destination.
		5: No effect.
		6: No effect.
		7: The compass will not mark the door!
		Bits 7+4 will enable waterfall effect.
        Bits 7+6 no mark, but works normally.
        Same for 7+5
        Same for 7+6+5
        Same for 7+4
        Unused bits seems to do nothing combined together, but if this is not the case, i'll update this.
        So, the compass data is another object for the future.
     *
     */
        }
    }
    //Prints and concatenates details about a door in the game that leads to a different area,
    public static void printdoorDetails(int doorNumber,byte[] rom) {	//Give it the room nr, and the rom itself, and it should print
        //door details on its own.
        int romOffset=0x190d;	//Base offset for the door parts in the ROM.
        int doornrRomOffset=romOffset+(doorNumber*5);	//Five bytes for each door, so roomNr*5+the offset.
        door tempDoor=new door();
        tempDoor.doorAddress=doornrRomOffset;
        tempDoor.door=getdoorType(doornrRomOffset,rom);
        tempDoor.roomnumber=rom[doornrRomOffset+1];
        tempDoor.columnplyrStarts=rom[doornrRomOffset+2];
        tempDoor.doorStart=rom[doornrRomOffset+3];
        tempDoor.doorEnd=rom[doornrRomOffset+4];
//------------------------------------------------------
        System.out.println("----------------DOOR DETAILS----------");
        System.out.println("Selected door number in the array: "+doorNumber);
        System.out.println("Door Address in ROM: "+String.format("0x%04X",(doornrRomOffset)));	//We need this in hexadecimal.
        System.out.println("Compass details. Numbers not zero means the given bit is set.");
        System.out.println("--------------------------------------");
        System.out.println("Going up: "+tempDoor.door.up);//Finally, object in an object!.
        System.out.println("Going down: "+tempDoor.door.down);
        System.out.println("Falldown: "+tempDoor.door.falldown);
        System.out.println("Unused1: "+tempDoor.door.unused1);
        System.out.println("Waterfall: "+tempDoor.door.waterfall);
        System.out.println("Unused2: "+tempDoor.door.unused2);
        System.out.println("Unused3: "+tempDoor.door.unused3);
        System.out.println("Show Compass: "+tempDoor.door.compassShow);
        System.out.println("--------------------------------------");
        System.out.println("Destination room Nr if door is taken: "+tempDoor.roomnumber);
        System.out.println("Column where the player spawns if door is taken: "+tempDoor.columnplyrStarts);
        System.out.println("Door Starting column: "+(tempDoor.doorStart&0xFF));
        System.out.println("Door Ending column: "+(tempDoor.doorEnd&0xFF));

    }   //As the name says, prints info about a door type. I have something similar elsewhere...
    public static door doorDetails(int doorNumber,byte[] rom) {
/*
This should be able to extract details with just a ROM address. Get the door details, and other things.
*/
/*	door currentDoor =new door();		//Create a door object, so we can determine the direction and other types of the door.
	currentDoor.doorAddress=doorAddress;	//Give the address of the door in ROM.
	currentDoor.door=getdoorType(doorAddress,rom);	//Based on these, fill in the missing details based on the bits of the type of the door.
	currentDoor.roomnumber=rom[doorAddress+1];	//Second byte is the room nr , same as before.
	currentDoor.columnplyrStarts=rom[doorAddress+2];	//Where the player will end, taking the door.
	currentDoor.doorStart=rom[doorAddress+3];
	currentDoor.doorEnd=rom[doorAddress+4];		//The start and ending coords.
	//The door is now good, and details should be available for printing.
*/
        int romOffset=0x190d;	//Base offset for the door parts in the ROM.
        int doornrRomOffset=0x190D+(doorNumber*5);	//Five bytes for each door, so roomNr*5+the offset.
        door tempDoor=new door();
        tempDoor.doorAddress=doornrRomOffset;
        tempDoor.door=getdoorType(doornrRomOffset,rom);
        tempDoor.roomnumber=rom[doornrRomOffset+1];
        tempDoor.columnplyrStarts=rom[doornrRomOffset+2];
        tempDoor.doorStart=rom[doornrRomOffset+3];
        tempDoor.doorEnd=rom[doornrRomOffset+4];

        return tempDoor;
    }
    public static doortype getdoorType(int address, byte[] rom){	//Returns a doortype based on the address, and gets the individual bytes.
        doortype dt =new doortype();
        int dbyte=rom[address] ;
        dt.up=dbyte&1;
        dt.down=dbyte&2;
        dt.falldown=dbyte&4;
        dt.unused1=dbyte&8;
        dt.waterfall=dbyte&16;
        dt.unused2=dbyte&32;
        dt.unused3=dbyte&64;
        dt.compassShow=dbyte&128;

        return dt;
    }   //The game handles each door differently, this is the behaviour of these. See inner comments.

}
