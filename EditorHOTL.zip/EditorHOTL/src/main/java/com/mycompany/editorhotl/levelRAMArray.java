package com.mycompany.editorhotl;

public class levelRAMArray {
    byte[] level=new byte[4096];
    /*
    * This is just the levels as how they are represented in the system memory, uncompressed.
    * I think I explained the level structure in the dissassembly, but here's the gist of it.
    * The level is made from 16x16 blocks, eight slices. The levels are stored like rows\stripes if you will.
    * This means the maximum level lenght with this game engine is 256*16 blocks.
    * Every 16x16 metatile is made up from smaller tiles of course.
    * The first 256 bytes are the first tiles of said metatiles.
    * Then the second 256 bytes are offsets, if the game uses the first or the second set of tiles.
    * Then comes the second tile and the rest. This is 1k of data. Of course, there's a lot of free space in this, since the
    * game could not use that many tiles for BG graphics, and it's usually not that "artsy" anyway.
    * After this, the rest are the bigger metatiles, row by row.
    * The code that loads the level also gets which bank to load the graphics from, but that's not really something I wanted to jump into.
    *
    * The graphics in VRAM are loaded sequentially, after the HUD graphics. Four tiles are one metatile one after another starting at $2180.
    * At least the game loads there.
    * Based on what does the game load tiles, I don't know yet. The code that handles level loading is not easy to follow after a while. I may lack the
    * necessary skill to do it.
    *
    * */
}
