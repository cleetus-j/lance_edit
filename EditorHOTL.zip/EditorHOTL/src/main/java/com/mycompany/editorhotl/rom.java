package com.mycompany.editorhotl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

//TODO: These manual paths should be really a parameter or something. These things are not existing on a computer that's not mine, so it's a bit odd.
//Mininal set of code to save, load and hash files.
public class rom {
    String path="//home//levi//devver//disas//HOTL//anotherexam//editor//";
    String fileName="Lance.sms";
    String protoFile="Heroes of the Lance [Proto].sms";
    String outputFile="Lance_mod.sms";
    String outFull=path+outputFile;
    String protoFileFullPath=path+protoFile;
    public static void saverom2(byte[] input){
        String path="//home//levi//devver//disas//HOTL//anotherexam//editor//";
        String outputFile="Lance_mod.sms";
        try {
            FileOutputStream fos=new FileOutputStream(new File(path+outputFile));
            fos.write(input);
            fos.close();
        }catch (IOException ex){
            ex.printStackTrace();

        }

    }   //This works as saving the result in the ROM. It does not overwrite the original.
    public static byte[] readRom (String filename){
        File file =new File(filename);
        int size=(int)file.length();
        byte[] rom=new byte[size];
        try {
            FileInputStream fis = new FileInputStream(new File(filename));
            fis.read(rom,0,rom.length);
            fis.close();
        } catch (IOException ex){

            ex.printStackTrace();
            System.out.println("There was a problem with the file.");
            System.exit(-1);
        }

        return rom;
    }   //Opens the ROM, and copies the contents into an array for further modification.
    public static Boolean checkIfExpanded(String fileName){
Boolean result=false;
    var filePath= Paths.get(fileName);
    byte[] rom=readRom(fileName);   //Get the ROM file, we'll do some rudimentary checksum crap, since the built in refuses to work for me.
    long fileHash=getHash(rom); //We will use this later on.
    long fSize=524288;
    //This is just a small thing, to see if the file is actually the same size or not.
    try {
        long size= Files.size(filePath);
        if (size==fSize){
    result=true;
        }else{
            result=false;
        }
    } catch (IOException e) {
        System.out.println("Dang, there's a problem with the file!");
        throw new RuntimeException(e);
    }
    return result;
}//Returns if the file is the orig size or not.
    public static long getHash(byte[] input){
        long hash=0;
        for (int i=0;i<input.length;i++){ //Calculate the "checksum", by adding the bytes together. An unaltered ROM should have the same value. Another one is the prototype, but that has different data structure.
            hash+=input[i];

        }

        return hash;
    }   //This adds every byte together, and forms a hash value, that are more or less used in real games as well.
}
