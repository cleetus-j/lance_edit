/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.editorhotl;

/**
 *
 * @author levi
 */
public class PitPointer {
    
    int pitCount;      //How many pits are on the given room. This can and will be used for the pit coordinates.
    PitCoordinate[] pits=new PitCoordinate[pitCount];   //Depending on how many pits are, we might need an array for this.
    public int[] getPitPointers(rom inputRom){
        int[] pitPointerArray=new int[89]; //There's more in this than how many levels are, but just in case.
        for (int i = 1; i < pitPointerArray.length; i++) {
            inputRom.getDumps(i);   //Open the given level's dumps.
            pitPointerArray[i]=bytesToInt(inputRom.ramDump, 0x1e5e,true);    //Get this one byte.
            if (pitPointerArray[i]==1761||pitPointerArray[i]==6117){
                System.out.println("The room has no pits\\no collision set.");
            }
            System.out.println("Pointer for room "+i+" is: "+Integer.toHexString(pitPointerArray[i]));
        }
        return pitPointerArray;
    }       //Gives back a list of pointers that are used per room. Done.
    public byte[] getPitListFromPointer(rom inputRom,int pointer){
        int tempPointer=pointer;            //This needs here, since we don't want to modify the pointer we receive to check.
        byte pitByte=0;
        if (inputRom.gameRom[tempPointer]==0){  //If the pointer points to a zero (no pits in the room), then return a 1 element array.
            /*No pit levels use 0x1761. $00 marks the end of the pits. Maybe even a two byte return array is good. I've not used new type of pits.
            * */
            return new byte[]{0};
        }
        while(inputRom.gameRom[tempPointer]!=0){
        pitByte++;
        tempPointer++;
        }       //We'll get the future array's length based on how many non-zero bytes are there.
        tempPointer=pointer;    //Reset the pointer.
        byte[] pitData=new byte[pitByte];   //now get the array created that will hold the values we'll give back.
        for (int i = 0; i < pitByte; i++) {
        pitData[i]=inputRom.gameRom[tempPointer+i];
        }       //Copy the data.
        return pitData;
    }   //This gets the pit coordinates in a nice variable length byte array. Since a room can have more than one pit.
    public static int bytesToInt(byte[] byteArray, int startIndex,boolean swapBytes) {
        if (byteArray == null || byteArray.length < startIndex + 2 || startIndex < 0) {
            throw new IllegalArgumentException("Invalid input byte array or start index.");
        }
        if(swapBytes){
            return ((byteArray[startIndex + 1] & 0xFF) << 8) | (byteArray[startIndex] & 0xFF); // Notice the swapped indices
        }else {
            return ((byteArray[startIndex] & 0xFF) << 8) | (byteArray[startIndex + 1] & 0xFF);
        }
    }   //Returns Pit coordinate pointers from all rooms. Can go between the original byte format, and swapped for "normal" use.
}
