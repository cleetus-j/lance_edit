/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.editorhotl;
//Exporting current levels work as a png.
//Tiles, metatiles can be exported, and potentially used.

//import org.apache.commons.lang3.ArrayUtils;

import java.io.IOException;

/**
 *
 * @author levi
 */
public class EditorHOTL {
/*
*         TODO list:
            -Metatiles should be exportable both as a picture, and as binary data, tilemap. (from already existing levels.)
                This would make easier to make up levels, by picking up the stuff we want from ready-made parts.
            -Building VRAM arrays from these parts, and tilemaps as well.
                Basically this is the level building part. Making up a list, csv or whatever that will concatenate and show the user how the level would look.
                There should be some check on how many tiles\metatiles are used, since VRAM is not unlimited.
                Data should be stored on which tiles are coming from which bank, if we want to use the original tile arrangement in the ROM.
                    TODO2: Think about some data structure, that will hold this.
            -Other parts, such as pits, monsters and items should be also accounted for. Their classes are empty atm.
            -Compass type class is empty! This is needed for doors.
            * -Door class should be checked if that's good, but I guess many things are missing.
            * -Doortype should be expanded to change doortypes of existing doors, and to aid creating more. (Also document it more.)
            * -Enemy class is very empty, aside from printing enemies. Make other things happen.
            * -Item seems to be fine, but worth a check.
            * -Clean up levelDetail. It's a mess. Connect the levels, and the details of course.
            * -ROM class is ALMOST good, yet some stuff could be moved there.   -Nah
          DONE:
          *     charstat is good as is. You can edit what you want, and save it in the ROM.
                companion seems to be good too.

*
* */

//public class Main {
    public static void main() throws IOException {
        rom origRom=new rom();
/*        for (int i = 1; i <89 ; i++) {
            origRom.getDumps(i);
            levelRAMArray.getAllMetaTiles(origRom,i);

        }
*/
        PitPointer test=new PitPointer();
        int[]pointerTest= test.getPitPointers(origRom);



}

}

