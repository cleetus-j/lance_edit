#Init PS GUI
Add-Type -AssemblyName System.Windows

$LocalPrinterForm=New-Object

system.Windows.Forms.Form
$LocalPrinterForm.ClientSize         = '500,300'
$LocalPrinterForm.text               = "LazyAdmin - PowerShell GUI Example"
$LocalPrinterForm.BackColor          = "#ffffff"
# Display the form
[void]$LocalPrinterForm.ShowDialog()