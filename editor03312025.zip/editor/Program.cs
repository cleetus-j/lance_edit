﻿using System;
using System.IO;
namespace editor;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        uint8[] gamerom=new uint8
    }
}
