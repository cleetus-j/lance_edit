import java.io.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.awt.Color;

public class TileDecoder {

    public static void main(String[] args) {
        String inputFilePath = "/media/MegaWork/devver/disas/HOTL/anotherexam/editor/room_vram/HOTL_mod_ah1.vrm"; // Path to the input file
        String outputFilePath = "/media/MegaWork/devver/disas/HOTL/anotherexam/editor/room_vram/HOTL_mod_ah1.bmp"; // Path to the output BMP file
        int tileSize = 8; // Each tile is 8x8 pixels
        int imageWidth = 64; // Width of the output image
        int imageHeight = 512; // Height of the output image

        // Example color palette (replace with actual palette data)
        Color[] colorPalette = {
     new Color(0,0,0),new Color(85,85,85),new Color(170,170,170),new Color(255,255,255),new Color(0,0,0),
    new Color(85,0,0),new Color(170,85,0),new Color(255,170,85),new Color(255,255,170),new Color(255,255,0),new Color(255,255,170),
    new Color(255,85,0),new Color(170,0,0),new Color(85,170,0),new Color(0,0,170),new Color(0,85,255)};
/*        for (int i = 0; i < colorPalette.length; i++) {
            colorPalette[i] = new Color(i * 16, i * 16, i * 16); // Grayscale palette
        } */

        try {
            // Read the tile data from the file
            byte[] tileData = readFile(inputFilePath);

            // Decode the tile data into a BufferedImage
            BufferedImage image = decodeTiles(tileData, tileSize, imageWidth, imageHeight, colorPalette);

            // Write the image to a BMP file
            ImageIO.write(image, "BMP", new File(outputFilePath));

            System.out.println("Image successfully written to " + outputFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static byte[] readFile(String filePath) throws IOException {
        File file = new File(filePath);
        byte[] data = new byte[(int) file.length()];
        try (FileInputStream fis = new FileInputStream(file)) {
            fis.read(data);
        }
        return data;
    }

    private static BufferedImage decodeTiles(byte[] tileData, int tileSize, int imageWidth, int imageHeight, Color[] colorPalette) {
        BufferedImage image = new BufferedImage(imageWidth, imageHeight, BufferedImage.TYPE_INT_RGB);
        int tilesPerRow = imageWidth / tileSize;
        int tilesPerColumn = imageHeight / tileSize;
        int tileIndex = 0;

        for (int tileY = 0; tileY < tilesPerColumn; tileY++) {
            for (int tileX = 0; tileX < tilesPerRow; tileX++) {
                int tileStartIndex = tileIndex * 32; // Each tile is 32 bytes
                for (int row = 0; row < tileSize; row++) {
                    int bitplane0 = tileData[tileStartIndex + row * 4] & 0xFF;
                    int bitplane1 = tileData[tileStartIndex + row * 4 + 1] & 0xFF;
                    int bitplane2 = tileData[tileStartIndex + row * 4 + 2] & 0xFF;
                    int bitplane3 = tileData[tileStartIndex + row * 4 + 3] & 0xFF;

                    for (int col = 0; col < tileSize; col++) {
                        int pixelValue = ((bitplane3 >> (7 - col)) & 1) << 3 |
                                        ((bitplane2 >> (7 - col)) & 1) << 2 |
                                        ((bitplane1 >> (7 - col)) & 1) << 1 |
                                        ((bitplane0 >> (7 - col)) & 1);
                        Color color = colorPalette[pixelValue];
                        int x = tileX * tileSize + col;
                        int y = tileY * tileSize + row;
                        image.setRGB(x, y, color.getRGB());
                    }
                }
                tileIndex++;
            }
        }

        return image;
    }
}