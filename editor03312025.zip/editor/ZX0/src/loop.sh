#!/bin/bash

#cd /media/work/devver/disas/HOTL/anotherexam/editor/ZX0/src/trunc/

for filename in *; do
    if [[ -d "$file_name" ]]; then
        echo "$file_name"
    fi
done
